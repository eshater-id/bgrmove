import os, sys, threading, traceback
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

BASE = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
os.environ["U2NET_HOME"] = str(BASE / "models")

from PIL import Image, ImageChops, ImageFilter
from rembg import remove, new_session

EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}
MODELS = {
    "Balanced — ISNet General": "isnet-general-use",
    "Maximum — BiRefNet General": "birefnet-general",
    "Portrait — BiRefNet Portrait": "birefnet-portrait",
    "Fast — U2Net": "u2net",
}
class App:
    def __init__(self, root):
        self.root=root; root.title("Batch Background Remover FINAL")
        root.geometry("900x700"); root.minsize(820,620)
        self.inp=tk.StringVar(); self.out=tk.StringVar()
        self.model=tk.StringVar(value=list(MODELS)[0])
        self.matting=tk.BooleanVar(value=True); self.dehalo=tk.BooleanVar(value=True)
        self.sub=tk.BooleanVar(value=True); self.over=tk.BooleanVar(value=False)
        self.running=False; self.stop=False

        tk.Label(root,text="BATCH BACKGROUND REMOVER",font=("Segoe UI",22,"bold")).pack(pady=(18,2))
        tk.Label(root,text="AI background removal • transparent PNG • batch processing",font=("Segoe UI",10)).pack(pady=(0,16))
        f=tk.Frame(root); f.pack(fill="x",padx=25)
        self.row(f,0,"Input folder",self.inp,self.pick_in)
        self.row(f,1,"Output folder",self.out,self.pick_out)

        opt=tk.LabelFrame(root,text="AI & Quality",padx=12,pady=10); opt.pack(fill="x",padx=25,pady=12)
        tk.Label(opt,text="AI model:").grid(row=0,column=0,sticky="w",padx=5,pady=5)
        ttk.Combobox(opt,textvariable=self.model,values=list(MODELS),state="readonly",width=34).grid(row=0,column=1,sticky="w",padx=5)
        tk.Checkbutton(opt,text="Alpha matting",variable=self.matting).grid(row=1,column=0,sticky="w",padx=5)
        tk.Checkbutton(opt,text="De-halo / edge cleanup",variable=self.dehalo).grid(row=1,column=1,sticky="w",padx=5)
        tk.Checkbutton(opt,text="Process subfolders",variable=self.sub).grid(row=1,column=2,sticky="w",padx=5)
        tk.Checkbutton(opt,text="Overwrite existing PNG",variable=self.over).grid(row=1,column=3,sticky="w",padx=5)

        b=tk.Frame(root); b.pack(fill="x",padx=25,pady=3)
        self.start=tk.Button(b,text="▶  START",height=2,font=("Segoe UI",11,"bold"),command=self.start_job)
        self.start.pack(side="left",fill="x",expand=True)
        self.stopb=tk.Button(b,text="■  STOP",height=2,state="disabled",command=self.stop_job); self.stopb.pack(side="left",padx=8)
        tk.Button(b,text="RESET",height=2,command=self.reset).pack(side="left")

        self.pb=ttk.Progressbar(root,maximum=100); self.pb.pack(fill="x",padx=25,pady=(14,4))
        self.status=tk.StringVar(value="Ready."); tk.Label(root,textvariable=self.status,anchor="w").pack(fill="x",padx=25)
        self.stats=tk.StringVar(value="Processed: 0   •   Passed: 0   •   Review: 0   •   Failed: 0")
        tk.Label(root,textvariable=self.stats,anchor="w").pack(fill="x",padx=25,pady=(2,4))
        self.log=tk.Text(root,height=18,state="disabled",font=("Consolas",9)); self.log.pack(fill="both",expand=True,padx=25,pady=8)

    def row(self,p,r,label,var,cmd):
        tk.Label(p,text=label,width=16,anchor="w").grid(row=r,column=0,pady=6)
        tk.Entry(p,textvariable=var).grid(row=r,column=1,sticky="ew",padx=8)
        tk.Button(p,text="Browse...",width=12,command=cmd).grid(row=r,column=2)
        p.columnconfigure(1,weight=1)
    def pick_in(self):
        p=filedialog.askdirectory(title="Select input folder")
        if p:
            self.inp.set(p)
            if not self.out.get(): self.out.set(str(Path(p)/"OUTPUT"))
    def pick_out(self):
        p=filedialog.askdirectory(title="Select output folder")
        if p:self.out.set(p)
    def logmsg(self,s):
        self.log.config(state="normal"); self.log.insert("end",s+"\n"); self.log.see("end"); self.log.config(state="disabled")
    def reset(self):
        if self.running:return
        self.inp.set(""); self.out.set(""); self.pb["value"]=0; self.status.set("Ready.")
        self.stats.set("Processed: 0   •   Passed: 0   •   Review: 0   •   Failed: 0")
        self.log.config(state="normal"); self.log.delete("1.0","end"); self.log.config(state="disabled")
    def start_job(self):
        if self.running:return
        src=Path(self.inp.get()); out=Path(self.out.get())
        if not src.is_dir(): messagebox.showwarning("Input","Pilih folder input yang valid."); return
        if not self.out.get(): messagebox.showwarning("Output","Pilih folder output."); return
        it=src.rglob("*") if self.sub.get() else src.iterdir()
        files=[p for p in it if p.is_file() and p.suffix.lower() in EXTS]
        if not files: messagebox.showinfo("No images","Tidak ada gambar yang didukung."); return
        out.mkdir(parents=True,exist_ok=True)
        self.running=True; self.stop=False; self.start.config(state="disabled"); self.stopb.config(state="normal")
        threading.Thread(target=self.worker,args=(src,out,files),daemon=True).start()
    def stop_job(self):
        self.stop=True; self.status.set("Stopping after current image...")
    def worker(self,src,out,files):
        ok=review=fail=skip=0; total=len(files)
        try:
            model_name=MODELS[self.model.get()]
            self.root.after(0,self.logmsg,f"Loading model: {model_name}")
            session=new_session(model_name)
            self.root.after(0,self.logmsg,"Model ready.")
        except Exception as e:
            self.root.after(0,self.logmsg,"MODEL ERROR: "+repr(e)); self.root.after(0,self.done,0,0,0,1); return
        for i,f in enumerate(files,1):
            if self.stop: break
            try:
                td=out/f.relative_to(src).parent if self.sub.get() else out
                td.mkdir(parents=True,exist_ok=True); target=td/(f.stem+".png")
                if target.exists() and not self.over.get():
                    skip+=1; msg=f"SKIP  {f.name}"
                else:
                    with open(f,"rb") as fi: data=fi.read()
                    kwargs={}
                    if self.matting:
                        kwargs.update(alpha_matting=True,alpha_matting_foreground_threshold=240,
                                      alpha_matting_background_threshold=10,alpha_matting_erode_size=10)
                    result=remove(data,session=session,**kwargs)
                    if self.dehalo:
                        result=self.dehalo_png(result)
                    with open(target,"wb") as fo: fo.write(result)
                    score,flag=self.quality(target)
                    if flag: review+=1
                    else: ok+=1
                    msg=f"{'REVIEW' if flag else 'OK'}  {f.name}  | quality {score}/100"
            except Exception as e:
                fail+=1; msg=f"ERROR {f.name} | {e}"
            self.root.after(0,self.logmsg,msg)
            self.root.after(0,self.progress,i,total,ok,review,fail)
        self.root.after(0,self.done,ok,review,skip,fail)
    def dehalo_png(self,data):
        # Conservative alpha cleanup; preserves the RGB edge while reducing nearly transparent dark/bright fringe.
        im=Image.open(__import__("io").BytesIO(data)).convert("RGBA")
        a=im.getchannel("A")
        # Slight median on alpha only, intentionally conservative.
        a=a.filter(ImageFilter.MedianFilter(3))
        im.putalpha(a)
        bio=__import__("io").BytesIO(); im.save(bio,"PNG"); return bio.getvalue()
    def quality(self,path):
        im=Image.open(path).convert("RGBA"); a=im.getchannel("A")
        hist=a.histogram(); total=sum(hist)
        transparent=sum(hist[:8]); opaque=sum(hist[248:])
        semi=total-transparent-opaque
        # Heuristic: excessive semi-transparent pixels can indicate uncertain edges.
        ratio=semi/max(total,1)
        score=max(0,min(100,round(100-ratio*90)))
        return score, score<82
    def progress(self,i,total,ok,review,fail):
        self.pb["value"]=i/total*100; self.status.set(f"Processing {i}/{total} ({i/total*100:.0f}%)")
        self.stats.set(f"Processed: {i}   •   Passed: {ok}   •   Review: {review}   •   Failed: {fail}")
    def done(self,ok,review,skip,fail):
        self.running=False; self.start.config(state="normal"); self.stopb.config(state="disabled")
        self.status.set(f"Finished • Passed {ok} • Review {review} • Skip {skip} • Failed {fail}")
        if not self.stop: messagebox.showinfo("Finished",f"Processing selesai.\n\nPassed: {ok}\nReview: {review}\nSkip: {skip}\nFailed: {fail}")

if __name__=="__main__":
    root=tk.Tk(); App(root); root.mainloop()
