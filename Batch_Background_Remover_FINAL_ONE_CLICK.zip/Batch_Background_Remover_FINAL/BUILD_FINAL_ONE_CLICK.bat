@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Batch Background Remover - FINAL ONE CLICK
echo ================================================
echo BATCH BACKGROUND REMOVER - FINAL
echo ================================================
echo.
set "PY="
for %%V in (3.13 3.12 3.11) do (
  py -%%V -c "import sys" >nul 2>&1
  if not errorlevel 1 if not defined PY set "PY=py -%%V"
)
if not defined PY (
  echo Python 3.11/3.12/3.13 tidak ditemukan.
  echo Silakan install Python 3.12 atau 3.13 dari python.org.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo [1/5] Creating environment...
  %PY% -m venv .venv || goto FAIL
)
set "VENV=%CD%\.venv\Scripts\python.exe"
echo [2/5] Installing/updating dependencies...
"%VENV%" -m pip install --upgrade pip || goto FAIL
"%VENV%" -m pip install "rembg[cpu]" pillow pyinstaller || goto FAIL
if not exist models mkdir models
set "U2NET_HOME=%CD%\models"
echo [3/5] Preparing U2Net model...
"%VENV%" -c "import os; os.environ['U2NET_HOME']=r'%CD%\models'; from rembg import new_session; new_session('u2net'); print('MODEL OK')" || goto FAIL
echo [4/5] Building...
rmdir /s /q build 2>nul
rmdir /s /q dist 2>nul
"%VENV%" -m PyInstaller --noconfirm --clean "Batch_Background_Remover.spec" || goto FAIL
echo [5/5] Creating Portable folder...
rmdir /s /q Portable 2>nul
mkdir "Portable\Batch Background Remover"
xcopy /e /i /y "dist\Batch Background Remover\*" "Portable\Batch Background Remover\" >nul
xcopy /e /i /y "models\*" "Portable\Batch Background Remover\models\" >nul
mkdir "Portable\Batch Background Remover\input" 2>nul
mkdir "Portable\Batch Background Remover\output" 2>nul
mkdir "Portable\Batch Background Remover\logs" 2>nul
echo.
echo BUILD BERHASIL. Membuka aplikasi...
start "" "Portable\Batch Background Remover\Batch Background Remover.exe"
exit /b 0
:FAIL
echo.
echo BUILD GAGAL. Screenshot/copy error di atas.
pause
exit /b 1
