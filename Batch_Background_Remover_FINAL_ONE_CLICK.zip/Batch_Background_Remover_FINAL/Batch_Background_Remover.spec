# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all, copy_metadata
datas=[]; binaries=[]; hiddenimports=[]
packages=["rembg","pymatting","pooch","onnxruntime","skimage","numpy","PIL"]
for pkg in packages:
    try:
        d,b,h=collect_all(pkg); datas+=d; binaries+=b; hiddenimports+=h
    except Exception: pass
for pkg in ["rembg","pymatting","pooch","onnxruntime","scikit-image","numpy","Pillow"]:
    try: datas += copy_metadata(pkg)
    except Exception: pass
a=Analysis(["app.py"],pathex=[],binaries=binaries,datas=datas,hiddenimports=hiddenimports,
           hookspath=[],hooksconfig={},runtime_hooks=[],excludes=[],noarchive=False)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name="Batch Background Remover",
        debug=False,bootloader_ignore_signals=False,strip=False,upx=False,console=False)
coll=COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name="Batch Background Remover")
